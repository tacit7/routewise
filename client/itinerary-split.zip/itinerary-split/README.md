# Itinerary Split (Sidebar + Trip Grid + Utils)

Drop these into your project:

- `pages/ItineraryPageShadcn.tsx`
- `components/DailyItinerarySidebar.tsx`
- `components/TripPlacesGrid.tsx`
- `utils/itinerary.ts`
- `types/itinerary.ts`

## What changed
- Extracted **DailyItinerarySidebar** and **TripPlacesGrid**.
- Added `utils/itinerary.ts` with `getIdentifier` and `sortByTime`.
- **TripPlacesGrid** includes a persisted **Show/Hide Map** toggle. Pass `mapsApiKey` to enable the map.

## Wiring
Update your imports to match your aliasing (`@/` and `@shared/` assumed).

## Notes
- Behavior stays the same as your current page, plus the map toggle in Trip Places.
